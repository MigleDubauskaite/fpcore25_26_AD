package fpcore25_26_AD.exceptions.jaula_pajaros;

public class JaulaNotAvailableException extends JaulaException{

	public JaulaNotAvailableException(String message) {
		super(message);
	}
}
