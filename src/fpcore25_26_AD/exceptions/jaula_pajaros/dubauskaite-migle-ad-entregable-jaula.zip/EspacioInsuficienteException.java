package fpcore25_26_AD.exceptions.jaula_pajaros;

public class EspacioInsuficienteException extends JaulaException {

	public EspacioInsuficienteException(String message) {
		super(message);
	}
}
