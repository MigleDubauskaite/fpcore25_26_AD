package fpcore25_26_AD.exceptions.jaula_pajaros;

public class JaulaException extends Exception {

	public JaulaException(String message) {
		super(message);
	}
}
